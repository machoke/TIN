# TIN


plik rules.txt zawiera reguły serwera
plik rulesclient zawiera reguły clienta

domyslne pliki konfiguracji to conf_client.ini i conf_server_ini